export const fakedata = [{
    "success": 1,
    "error": 0,
    "data": [{
        "createdAt": "2022-04-03T20:47:12.000Z",
        "updatedAt": null,
        "id": 137000,
        "url": "https://www.instagram.com/p/CJHrc4fgREf",
        "account": "yarashahidi",
        "network": 2,
        "currentViews": 0,
        "currentShares": null,
        "currentLikes": 143330,
        "currentComments": 390,
        "currentDislikes": null,
        "postedAt": "2020-12-23T00:22:23.000Z",
        "caption": "I am fortunate to be home for the holidays with my favorite people...my family 🥰 This year we had the opportunity to create a peek into our holiday. Check out our video on the @SamsungUs YouTube channel! #familytime \n#SamsungPartner #withGalaxy (LINK IN BIO)🥰",
        "thumbnailUrl": "thumbnails/3caf57c858.jpg",
        "type": 3,
        "credits": [{
                "createdAt": "2022-04-03T20:47:29.000Z",
                "updatedAt": null,
                "id": 251148,
                "userId": 5371,
                "roleId": 71,
                "postId": 137000,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "parentCredit": null,
                "user": {
                    "id": 5371,
                    "name": "Samsung Electronics",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                    "userTypeId": 1,
                    "username": "Samsung",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 71,
                    "name": "Talent Agency",
                    "weighting": 400,
                    "phasedOut": false
                }
            },
            {
                "createdAt": "2022-04-03T20:47:29.000Z",
                "updatedAt": null,
                "id": 251149,
                "userId": 7215,
                "roleId": 111,
                "postId": 137000,
                "parentCreditId": 251148,
                "isPrivate": false,
                "isHidden": false,
                "parentCredit": {
                    "createdAt": "2022-04-03T20:47:29.000Z",
                    "updatedAt": null,
                    "postId": 137000,
                    "parentCreditId": null,
                    "isPrivate": false,
                    "isHidden": false,
                    "user": {
                        "id": 5371,
                        "name": "Samsung Electronics",
                        "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                        "userTypeId": 1,
                        "username": "Samsung",
                        "termsAcknowledged": false,
                        "userPermissions": [],
                        "defaultRoleId": null,
                        "isPro": false,
                        "isOG": false,
                        "isAdmin": false,
                        "isBeta": false,
                        "isFreePro": false
                    },
                    "role": {
                        "id": 71,
                        "name": "Talent Agency",
                        "weighting": 400,
                        "phasedOut": false
                    }
                },
                "user": {
                    "id": 7215,
                    "name": "Kelsy L Alston",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                    "userTypeId": 2,
                    "username": "Kelsylockett",
                    "termsAcknowledged": true,
                    "userPermissions": [{
                        "createdAt": "2022-04-03T20:27:44.000Z",
                        "updatedAt": null,
                        "id": 7674,
                        "userId": 7215,
                        "permission": 0
                    }],
                    "defaultRoleId": 111,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 111,
                    "name": "Talent Manager",
                    "weighting": 0,
                    "phasedOut": false
                }
            }
        ],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T20:44:52.000Z",
        "updatedAt": null,
        "id": 136994,
        "url": "https://www.instagram.com/p/B__FdiJgCxA",
        "account": "yarashahidi",
        "network": 2,
        "currentViews": 0,
        "currentShares": null,
        "currentLikes": 123155,
        "currentComments": 415,
        "currentDislikes": null,
        "postedAt": "2020-05-09T23:33:57.000Z",
        "caption": "💕@CHOCOLATEMOMMYLUV PHOTO WAS TAKEN BY HER BIGGEST FAN -> ME 💞While this Mother’s Day feels different for many of us,  If you’re with your mama or someone who holds that space: Join me and use your phone to put them in the frame⭐️ If you are not with your mother or they are no longer here to be celebrated,  honor them by sharing a special picture⭐️ I snapped these photos of my beautiful Mama #withGalaxy S20 Ultra! @SamsungMobileUSA #MothersDay #SamsungPartner#chocolatemommyluv 👸🏾",
        "thumbnailUrl": "thumbnails/a6d701ca56.jpg",
        "type": 3,
        "credits": [{
            "createdAt": "2022-04-03T20:45:25.000Z",
            "updatedAt": null,
            "id": 251133,
            "userId": 5371,
            "roleId": 71,
            "postId": 136994,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 5371,
                "name": "Samsung Electronics",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                "userTypeId": 1,
                "username": "Samsung",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 71,
                "name": "Talent Agency",
                "weighting": 400,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T20:45:25.000Z",
            "updatedAt": null,
            "id": 251134,
            "userId": 7215,
            "roleId": 111,
            "postId": 136994,
            "parentCreditId": 251133,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T20:45:25.000Z",
                "updatedAt": null,
                "postId": 136994,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 5371,
                    "name": "Samsung Electronics",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                    "userTypeId": 1,
                    "username": "Samsung",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 71,
                    "name": "Talent Agency",
                    "weighting": 400,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:09:33.000Z",
        "updatedAt": null,
        "id": 137029,
        "url": "https://www.tiktok.com/@richardjasso/video/7076540284712045866",
        "account": "richardjasso",
        "network": 5,
        "currentViews": 16300000,
        "currentShares": 321,
        "currentLikes": 121700,
        "currentComments": 985,
        "currentDislikes": null,
        "postedAt": "2022-03-18T20:30:30.000Z",
        "caption": "#ad Real or Fake? Share your own @cheezit #GetThatCheddarEntry by April 15! #art #realorfake #realistic #drawing   Rules: Cheezit.com/getthatcheddar",
        "thumbnailUrl": "thumbnails/2c6c633c13.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:09:46.000Z",
            "updatedAt": null,
            "id": 251216,
            "userId": 7218,
            "roleId": 111,
            "postId": 137029,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7218,
                "name": "Weber Shandwick",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                "userTypeId": 1,
                "username": "WeberShandwick",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:09:46.000Z",
            "updatedAt": null,
            "id": 251217,
            "userId": 7215,
            "roleId": 111,
            "postId": 137029,
            "parentCreditId": 251216,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:09:46.000Z",
                "updatedAt": null,
                "postId": 137029,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 7218,
                    "name": "Weber Shandwick",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                    "userTypeId": 1,
                    "username": "WeberShandwick",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 111,
                    "name": "Talent Manager",
                    "weighting": 0,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:11:04.000Z",
        "updatedAt": null,
        "id": 137031,
        "url": "https://www.tiktok.com/@jackieaina/video/7079082234682101035",
        "account": "jackieaina",
        "network": 5,
        "currentViews": 4400000,
        "currentShares": 151,
        "currentLikes": 50600,
        "currentComments": 385,
        "currentDislikes": null,
        "postedAt": "2022-03-25T16:54:34.000Z",
        "caption": "#disclosure @Ancestry these women inspire me simply because they existed 🤎 #ancestrypartner #myancestrystory",
        "thumbnailUrl": "thumbnails/660feddaa4.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:11:14.000Z",
            "updatedAt": null,
            "id": 251220,
            "userId": 7218,
            "roleId": 111,
            "postId": 137031,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7218,
                "name": "Weber Shandwick",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                "userTypeId": 1,
                "username": "WeberShandwick",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:11:14.000Z",
            "updatedAt": null,
            "id": 251221,
            "userId": 7215,
            "roleId": 111,
            "postId": 137031,
            "parentCreditId": 251220,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:11:14.000Z",
                "updatedAt": null,
                "postId": 137031,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 7218,
                    "name": "Weber Shandwick",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                    "userTypeId": 1,
                    "username": "WeberShandwick",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 111,
                    "name": "Talent Manager",
                    "weighting": 0,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:10:18.000Z",
        "updatedAt": null,
        "id": 137030,
        "url": "https://www.tiktok.com/@ashyizzle/video/7080204199987891502",
        "account": "ashyizzle",
        "network": 5,
        "currentViews": 3700000,
        "currentShares": 146,
        "currentLikes": 48400,
        "currentComments": 336,
        "currentDislikes": null,
        "postedAt": "2022-03-28T17:28:22.000Z",
        "caption": "#ad This @Cheez-It  snack is ELITE ✨ Share your fav Cheez-It pairing with #GetThatCheddarEntry | Rules: Cheezit.com/GetThatCheddar",
        "thumbnailUrl": "thumbnails/a385a4d9a6.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:10:28.000Z",
            "updatedAt": null,
            "id": 251218,
            "userId": 7218,
            "roleId": 111,
            "postId": 137030,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7218,
                "name": "Weber Shandwick",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                "userTypeId": 1,
                "username": "WeberShandwick",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:10:28.000Z",
            "updatedAt": null,
            "id": 251219,
            "userId": 7215,
            "roleId": 111,
            "postId": 137030,
            "parentCreditId": 251218,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:10:28.000Z",
                "updatedAt": null,
                "postId": 137030,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 7218,
                    "name": "Weber Shandwick",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                    "userTypeId": 1,
                    "username": "WeberShandwick",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 111,
                    "name": "Talent Manager",
                    "weighting": 0,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:17:13.000Z",
        "updatedAt": null,
        "id": 137038,
        "url": "https://www.tiktok.com/@dadandboujiee/video/7034263005021916421",
        "account": "dadandboujiee",
        "network": 5,
        "currentViews": 596700,
        "currentShares": 33,
        "currentLikes": 19600,
        "currentComments": 92,
        "currentDislikes": null,
        "postedAt": "2021-11-24T22:13:04.000Z",
        "caption": "#Ad I’m always trying to learn more about myself!! #DadLife #Fyp #family #AncestryDNA #AncestryPartner @Ancestry",
        "thumbnailUrl": "thumbnails/142c308a57.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:17:22.000Z",
            "updatedAt": null,
            "id": 251234,
            "userId": 7218,
            "roleId": 111,
            "postId": 137038,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7218,
                "name": "Weber Shandwick",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                "userTypeId": 1,
                "username": "WeberShandwick",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:17:22.000Z",
            "updatedAt": null,
            "id": 251235,
            "userId": 7215,
            "roleId": 111,
            "postId": 137038,
            "parentCreditId": 251234,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:17:22.000Z",
                "updatedAt": null,
                "postId": 137038,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 7218,
                    "name": "Weber Shandwick",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                    "userTypeId": 1,
                    "username": "WeberShandwick",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 111,
                    "name": "Talent Manager",
                    "weighting": 0,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T20:43:09.000Z",
        "updatedAt": null,
        "id": 136990,
        "url": "https://www.instagram.com/p/CALZtbTgu-A",
        "account": "yarashahidi",
        "network": 2,
        "currentViews": 103512,
        "currentShares": null,
        "currentLikes": 15600,
        "currentComments": 120,
        "currentDislikes": null,
        "postedAt": "2020-05-14T18:30:37.000Z",
        "caption": "⭐️My Throwback Moments and Memories are amplified with Gratitude ⭐️I am blown away thinking about places I've been fortunate enough to explore & the incredible people that have come into my world. Paris Fashion Week with @Samsungmobileusa x @ThomBrowneny was dreamy & inspiring and I used my #SamsungThomBrowne flip phone to capture the day &  lots of up close moments ⭐️Loving being #TeamGalaxy because they empower & support creativity. I’m smiling, thinking back to these moments in the beautiful city of Paris. Open your phone gallery & scroll through your photo memories to inspire your next creative moments❤️ #SamsungPartner #SamsungThomBrowne #tbt",
        "thumbnailUrl": "thumbnails/393414889c.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T20:44:07.000Z",
            "updatedAt": null,
            "id": 251122,
            "userId": 5371,
            "roleId": 71,
            "postId": 136990,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 5371,
                "name": "Samsung Electronics",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                "userTypeId": 1,
                "username": "Samsung",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 71,
                "name": "Talent Agency",
                "weighting": 400,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T20:44:07.000Z",
            "updatedAt": null,
            "id": 251123,
            "userId": 7215,
            "roleId": 111,
            "postId": 136990,
            "parentCreditId": 251122,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T20:44:07.000Z",
                "updatedAt": null,
                "postId": 136990,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 5371,
                    "name": "Samsung Electronics",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                    "userTypeId": 1,
                    "username": "Samsung",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 71,
                    "name": "Talent Agency",
                    "weighting": 400,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:16:18.000Z",
        "updatedAt": null,
        "id": 137036,
        "url": "https://www.tiktok.com/@yourfavafricanyfa/video/7036509220531047727",
        "account": "yourfavafricanyfa",
        "network": 5,
        "currentViews": 391100,
        "currentShares": 19,
        "currentLikes": 12300,
        "currentComments": 83,
        "currentDislikes": null,
        "postedAt": "2021-11-30T23:35:46.000Z",
        "caption": "#ad @Ancestry #AncestryDNA #AncestryPartner",
        "thumbnailUrl": "thumbnails/0ef34b847b.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:16:39.000Z",
            "updatedAt": null,
            "id": 251230,
            "userId": 7215,
            "roleId": 111,
            "postId": 137036,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:16:39.000Z",
            "updatedAt": null,
            "id": 251231,
            "userId": 7218,
            "roleId": 111,
            "postId": 137036,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7218,
                "name": "Weber Shandwick",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                "userTypeId": 1,
                "username": "WeberShandwick",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:15:49.000Z",
        "updatedAt": null,
        "id": 137035,
        "url": "https://www.tiktok.com/@darinandjosh/video/7036145364524666117",
        "account": "darinandjosh",
        "network": 5,
        "currentViews": 372700,
        "currentShares": 15,
        "currentLikes": 10200,
        "currentComments": 49,
        "currentDislikes": null,
        "postedAt": "2021-11-29T23:57:35.000Z",
        "caption": "#ad Discovering our family history with @ancestry #AncestryDNA #AncestryPartner",
        "thumbnailUrl": "thumbnails/e93501a77f.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:15:58.000Z",
            "updatedAt": null,
            "id": 251228,
            "userId": 7218,
            "roleId": 111,
            "postId": 137035,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7218,
                "name": "Weber Shandwick",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                "userTypeId": 1,
                "username": "WeberShandwick",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:15:58.000Z",
            "updatedAt": null,
            "id": 251229,
            "userId": 7215,
            "roleId": 111,
            "postId": 137035,
            "parentCreditId": 251228,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:15:58.000Z",
                "updatedAt": null,
                "postId": 137035,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 7218,
                    "name": "Weber Shandwick",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                    "userTypeId": 1,
                    "username": "WeberShandwick",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 111,
                    "name": "Talent Manager",
                    "weighting": 0,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:16:52.000Z",
        "updatedAt": null,
        "id": 137037,
        "url": "https://www.tiktok.com/@thestoleys/video/7035036467885886766",
        "account": "thestoleys",
        "network": 5,
        "currentViews": 392200,
        "currentShares": 28,
        "currentLikes": 9562,
        "currentComments": 104,
        "currentDislikes": null,
        "postedAt": "2021-11-27T00:14:30.000Z",
        "caption": "#ad  I cannot wait to get my results and share them with you! #AncestryDNA #AncestryPartner @ancestry",
        "thumbnailUrl": "thumbnails/2faad13818.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:17:02.000Z",
            "updatedAt": null,
            "id": 251232,
            "userId": 7218,
            "roleId": 111,
            "postId": 137037,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7218,
                "name": "Weber Shandwick",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                "userTypeId": 1,
                "username": "WeberShandwick",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:17:02.000Z",
            "updatedAt": null,
            "id": 251233,
            "userId": 7215,
            "roleId": 111,
            "postId": 137037,
            "parentCreditId": 251232,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:17:02.000Z",
                "updatedAt": null,
                "postId": 137037,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 7218,
                    "name": "Weber Shandwick",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                    "userTypeId": 1,
                    "username": "WeberShandwick",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 111,
                    "name": "Talent Manager",
                    "weighting": 0,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:13:59.000Z",
        "updatedAt": null,
        "id": 137034,
        "url": "https://www.tiktok.com/@retirementhouse/video/7078396922855263534",
        "account": "retirementhouse",
        "network": 5,
        "currentViews": 109900,
        "currentShares": 21,
        "currentLikes": 6801,
        "currentComments": 95,
        "currentDislikes": null,
        "postedAt": "2022-03-23T20:35:12.000Z",
        "caption": "#ad #stitch with @ancestry I can’t wait to learn more about my family history! Thank you Ancestry! #MyAncestryStory #AncestryPartner",
        "thumbnailUrl": "thumbnails/b243abc086.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:14:08.000Z",
            "updatedAt": null,
            "id": 251226,
            "userId": 7218,
            "roleId": 111,
            "postId": 137034,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7218,
                "name": "Weber Shandwick",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                "userTypeId": 1,
                "username": "WeberShandwick",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:14:08.000Z",
            "updatedAt": null,
            "id": 251227,
            "userId": 7215,
            "roleId": 111,
            "postId": 137034,
            "parentCreditId": 251226,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:14:08.000Z",
                "updatedAt": null,
                "postId": 137034,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 7218,
                    "name": "Weber Shandwick",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                    "userTypeId": 1,
                    "username": "WeberShandwick",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 111,
                    "name": "Talent Manager",
                    "weighting": 0,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:11:36.000Z",
        "updatedAt": null,
        "id": 137032,
        "url": "https://www.tiktok.com/@team2moms/video/7079126217382841646",
        "account": "team2moms",
        "network": 5,
        "currentViews": 92700,
        "currentShares": 5,
        "currentLikes": 5982,
        "currentComments": 43,
        "currentDislikes": null,
        "postedAt": "2022-03-25T19:45:14.000Z",
        "caption": "#ad #stitch with @ancestry  In celebration of Women’s History Month, we are sharing the women in our family who have inspired us. Share a story of a woman in your family who inspired you with #MyAncestryStory.",
        "thumbnailUrl": "thumbnails/d65e26bf9b.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:11:46.000Z",
            "updatedAt": null,
            "id": 251222,
            "userId": 7218,
            "roleId": 111,
            "postId": 137032,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7218,
                "name": "Weber Shandwick",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                "userTypeId": 1,
                "username": "WeberShandwick",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:11:46.000Z",
            "updatedAt": null,
            "id": 251223,
            "userId": 7215,
            "roleId": 111,
            "postId": 137032,
            "parentCreditId": 251222,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:11:46.000Z",
                "updatedAt": null,
                "postId": 137032,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 7218,
                    "name": "Weber Shandwick",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                    "userTypeId": 1,
                    "username": "WeberShandwick",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 111,
                    "name": "Talent Manager",
                    "weighting": 0,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:08:47.000Z",
        "updatedAt": null,
        "id": 137028,
        "url": "https://www.instagram.com/p/B8__bElpX9i",
        "account": "lancefresh",
        "network": 2,
        "currentViews": 0,
        "currentShares": null,
        "currentLikes": 2573,
        "currentComments": 38,
        "currentDislikes": null,
        "postedAt": "2020-02-25T18:26:15.000Z",
        "caption": "Here are some of my favorite moments from All Star Weekend in Chicago - caught with the new Samsung Galaxy Z Flip #TeamGalaxy #Samsungpartner",
        "thumbnailUrl": "thumbnails/db166a520e.jpg",
        "type": 3,
        "credits": [{
            "createdAt": "2022-04-03T21:08:57.000Z",
            "updatedAt": null,
            "id": 251214,
            "userId": 5371,
            "roleId": 71,
            "postId": 137028,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 5371,
                "name": "Samsung Electronics",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                "userTypeId": 1,
                "username": "Samsung",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 71,
                "name": "Talent Agency",
                "weighting": 400,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:08:57.000Z",
            "updatedAt": null,
            "id": 251215,
            "userId": 7215,
            "roleId": 111,
            "postId": 137028,
            "parentCreditId": 251214,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:08:57.000Z",
                "updatedAt": null,
                "postId": 137028,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 5371,
                    "name": "Samsung Electronics",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                    "userTypeId": 1,
                    "username": "Samsung",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 71,
                    "name": "Talent Agency",
                    "weighting": 400,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:12:27.000Z",
        "updatedAt": null,
        "id": 137033,
        "url": "https://www.tiktok.com/@bonnieleetoks/video/7077989673850834222",
        "account": "bonnieleetoks",
        "network": 5,
        "currentViews": 26500,
        "currentShares": 1,
        "currentLikes": 1897,
        "currentComments": 28,
        "currentDislikes": null,
        "postedAt": "2022-03-22T18:14:53.000Z",
        "caption": "#ad #stitch with @ancestry #ad Check out Ancestry to find out more about the amazing women in your life and share using #MyAncestryStory",
        "thumbnailUrl": "thumbnails/5822c0cc7c.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:13:37.000Z",
            "updatedAt": null,
            "id": 251224,
            "userId": 7218,
            "roleId": 111,
            "postId": 137033,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7218,
                "name": "Weber Shandwick",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                "userTypeId": 1,
                "username": "WeberShandwick",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:13:37.000Z",
            "updatedAt": null,
            "id": 251225,
            "userId": 7215,
            "roleId": 111,
            "postId": 137033,
            "parentCreditId": 251224,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:13:37.000Z",
                "updatedAt": null,
                "postId": 137033,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 7218,
                    "name": "Weber Shandwick",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
                    "userTypeId": 1,
                    "username": "WeberShandwick",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 111,
                    "name": "Talent Manager",
                    "weighting": 0,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:06:34.000Z",
        "updatedAt": null,
        "id": 137023,
        "url": "https://www.instagram.com/p/CCuCZZkpRU_",
        "account": "lancefresh",
        "network": 2,
        "currentViews": 4327,
        "currentShares": null,
        "currentLikes": 1889,
        "currentComments": 80,
        "currentDislikes": null,
        "postedAt": "2020-07-16T22:14:27.000Z",
        "caption": "Y’all know I have to get the latest and greatest!🌊\n\nMuch love to @SamsungUS for providing finishing touch vibes to my living room with the #QLED4K #SmartTV. It has a little something for everyone!\n\nCheck out the best of sports lifestyle with content by yours truly on Samsung TV Plus’s free app - @PlayersTV. It’s good to be a #SamsungPartner",
        "thumbnailUrl": "thumbnails/c379be66bf.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:06:44.000Z",
            "updatedAt": null,
            "id": 251204,
            "userId": 5371,
            "roleId": 71,
            "postId": 137023,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 5371,
                "name": "Samsung Electronics",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                "userTypeId": 1,
                "username": "Samsung",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 71,
                "name": "Talent Agency",
                "weighting": 400,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:06:44.000Z",
            "updatedAt": null,
            "id": 251205,
            "userId": 7215,
            "roleId": 111,
            "postId": 137023,
            "parentCreditId": 251204,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:06:44.000Z",
                "updatedAt": null,
                "postId": 137023,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 5371,
                    "name": "Samsung Electronics",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                    "userTypeId": 1,
                    "username": "Samsung",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 71,
                    "name": "Talent Agency",
                    "weighting": 400,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:07:23.000Z",
        "updatedAt": null,
        "id": 137025,
        "url": "https://www.instagram.com/p/CGAoHiHpTB2",
        "account": "lancefresh",
        "network": 2,
        "currentViews": 4909,
        "currentShares": null,
        "currentLikes": 1646,
        "currentComments": 79,
        "currentDislikes": null,
        "postedAt": "2020-10-06T17:04:57.000Z",
        "caption": "Born & raised in NYC with culture and creativity running through my veins - raising the sneaker unboxing bar with @SamsungMobileUSA Galaxy Z Flip. This phone is my go-to for my day-to-day and I used it to show y’all a deeper look into the city that made me who I am and what my process is like.  Can’t wait to see what I’ll create next #SamsungPartner #TeamGalaxy.",
        "thumbnailUrl": "thumbnails/5ef901ded1.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:07:32.000Z",
            "updatedAt": null,
            "id": 251208,
            "userId": 5371,
            "roleId": 71,
            "postId": 137025,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 5371,
                "name": "Samsung Electronics",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                "userTypeId": 1,
                "username": "Samsung",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 71,
                "name": "Talent Agency",
                "weighting": 400,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:07:32.000Z",
            "updatedAt": null,
            "id": 251209,
            "userId": 7215,
            "roleId": 111,
            "postId": 137025,
            "parentCreditId": 251208,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:07:32.000Z",
                "updatedAt": null,
                "postId": 137025,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 5371,
                    "name": "Samsung Electronics",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                    "userTypeId": 1,
                    "username": "Samsung",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 71,
                    "name": "Talent Agency",
                    "weighting": 400,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:06:58.000Z",
        "updatedAt": null,
        "id": 137024,
        "url": "https://www.instagram.com/p/CFSmPhfJdBB",
        "account": "lancefresh",
        "network": 2,
        "currentViews": 0,
        "currentShares": null,
        "currentLikes": 1588,
        "currentComments": 68,
        "currentDislikes": null,
        "postedAt": "2020-09-18T20:02:56.000Z",
        "caption": "Hyped to have my new @Samsungmobileusa Galaxy Z Fold2 5G with the new Ultrawide camera and Flex mode that lets me get hands free shots from different angles.\n\nI also can’t wait to tap into the cool benefits of being a part of Galaxy Z premier - like the ClubLife benefit that I’m about to use to hit up the golf course for the first time. \n\n#SamsungPartner #TeamGalaxy",
        "thumbnailUrl": "thumbnails/7f47ef9da9.jpg",
        "type": 3,
        "credits": [{
            "createdAt": "2022-04-03T21:07:08.000Z",
            "updatedAt": null,
            "id": 251206,
            "userId": 5371,
            "roleId": 71,
            "postId": 137024,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 5371,
                "name": "Samsung Electronics",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                "userTypeId": 1,
                "username": "Samsung",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 71,
                "name": "Talent Agency",
                "weighting": 400,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:07:08.000Z",
            "updatedAt": null,
            "id": 251207,
            "userId": 7215,
            "roleId": 111,
            "postId": 137024,
            "parentCreditId": 251206,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:07:08.000Z",
                "updatedAt": null,
                "postId": 137024,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 5371,
                    "name": "Samsung Electronics",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                    "userTypeId": 1,
                    "username": "Samsung",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 71,
                    "name": "Talent Agency",
                    "weighting": 400,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:07:54.000Z",
        "updatedAt": null,
        "id": 137026,
        "url": "https://www.instagram.com/p/CGYcPXRJYil",
        "account": "lancefresh",
        "network": 2,
        "currentViews": 3974,
        "currentShares": null,
        "currentLikes": 1554,
        "currentComments": 53,
        "currentDislikes": null,
        "postedAt": "2020-10-15T23:03:14.000Z",
        "caption": "You know being a #SamsungPartner, I always get hooked up with the latest and greatest. With the Galaxy S20 5G UW, I get to show you guys part shoe collection, using its top of the line camera capabilities!\n\nLet me know which pair y’all are feeling the most! \n@SamsungmobileUSA #TeamGalaxy",
        "thumbnailUrl": "thumbnails/867a634eee.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T21:08:02.000Z",
            "updatedAt": null,
            "id": 251210,
            "userId": 5371,
            "roleId": 71,
            "postId": 137026,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 5371,
                "name": "Samsung Electronics",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                "userTypeId": 1,
                "username": "Samsung",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 71,
                "name": "Talent Agency",
                "weighting": 400,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:08:02.000Z",
            "updatedAt": null,
            "id": 251211,
            "userId": 7215,
            "roleId": 111,
            "postId": 137026,
            "parentCreditId": 251210,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:08:02.000Z",
                "updatedAt": null,
                "postId": 137026,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 5371,
                    "name": "Samsung Electronics",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                    "userTypeId": 1,
                    "username": "Samsung",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 71,
                    "name": "Talent Agency",
                    "weighting": 400,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T21:08:15.000Z",
        "updatedAt": null,
        "id": 137027,
        "url": "https://www.instagram.com/p/CI1KZOHrxr1",
        "account": "lancefresh",
        "network": 2,
        "currentViews": 0,
        "currentShares": null,
        "currentLikes": 1463,
        "currentComments": 51,
        "currentDislikes": null,
        "postedAt": "2020-12-15T19:47:12.000Z",
        "caption": "Y’all know I always gotta keep up with the newest drip, including my phone. \n\nSo hyped to receive the latest and greatest Thom Browne device from @samsungmobileUSA This Z Fold2 5G - Thom Browne edition is next level. #SamsungPartner #TeamGalaxy",
        "thumbnailUrl": "thumbnails/5e222e037f.jpg",
        "type": 3,
        "credits": [{
            "createdAt": "2022-04-03T21:08:23.000Z",
            "updatedAt": null,
            "id": 251212,
            "userId": 5371,
            "roleId": 71,
            "postId": 137027,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 5371,
                "name": "Samsung Electronics",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                "userTypeId": 1,
                "username": "Samsung",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 71,
                "name": "Talent Agency",
                "weighting": 400,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T21:08:23.000Z",
            "updatedAt": null,
            "id": 251213,
            "userId": 7215,
            "roleId": 111,
            "postId": 137027,
            "parentCreditId": 251212,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T21:08:23.000Z",
                "updatedAt": null,
                "postId": 137027,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 5371,
                    "name": "Samsung Electronics",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                    "userTypeId": 1,
                    "username": "Samsung",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 71,
                    "name": "Talent Agency",
                    "weighting": 400,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T22:29:25.000Z",
        "updatedAt": null,
        "id": 137050,
        "url": "https://www.instagram.com/p/B7ouJkTBsFU",
        "account": "b.scar",
        "network": 2,
        "currentViews": 0,
        "currentShares": null,
        "currentLikes": 1181,
        "currentComments": 29,
        "currentDislikes": null,
        "postedAt": "2020-01-22T21:01:23.000Z",
        "caption": "BIG DROP ALERT! #BScarTV went red carpet last night at the Houston Sports Awards. Some very, very special guests - HI QUALITY soon come...",
        "thumbnailUrl": "thumbnails/a7c4fa6161.jpg",
        "type": 3,
        "credits": [{
            "createdAt": "2022-04-03T22:29:37.000Z",
            "updatedAt": null,
            "id": 251264,
            "userId": 7215,
            "roleId": 55,
            "postId": 137050,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 55,
                "name": "Content Strategist",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T22:29:37.000Z",
            "updatedAt": null,
            "id": 251265,
            "userId": 7215,
            "roleId": 111,
            "postId": 137050,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T22:30:42.000Z",
        "updatedAt": null,
        "id": 137051,
        "url": "https://www.instagram.com/p/B61Z6SoBDNC",
        "account": "b.scar",
        "network": 2,
        "currentViews": 2381,
        "currentShares": null,
        "currentLikes": 506,
        "currentComments": 22,
        "currentDislikes": null,
        "postedAt": "2020-01-02T22:53:38.000Z",
        "caption": "The @thebigyard family and I hope that everyone had a wonderful holiday season! Thank you to Emerson Elementary for allowing me to come by and share my love of reading. Big things soon come for 2020 📚 🌳 ❤️",
        "thumbnailUrl": "thumbnails/74bf6d7e78.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T22:30:53.000Z",
            "updatedAt": null,
            "id": 251266,
            "userId": 7215,
            "roleId": 111,
            "postId": 137051,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T22:30:53.000Z",
            "updatedAt": null,
            "id": 251267,
            "userId": 7215,
            "roleId": 55,
            "postId": 137051,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 55,
                "name": "Content Strategist",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T22:27:43.000Z",
        "updatedAt": null,
        "id": 137047,
        "url": "https://www.instagram.com/p/CC9Pw22Bt2C",
        "account": "b.scar",
        "network": 2,
        "currentViews": 0,
        "currentShares": null,
        "currentLikes": 419,
        "currentComments": 3,
        "currentDislikes": null,
        "postedAt": "2020-07-22T19:59:40.000Z",
        "caption": "“Uh... hello?” @dj_sneakerhead lucky he don’t wear a 15 or these might have to be mine 😂 — Creator series Ep. 2 on IGTV",
        "thumbnailUrl": "thumbnails/5f040efd44.jpg",
        "type": 3,
        "credits": [{
            "createdAt": "2022-04-03T22:27:55.000Z",
            "updatedAt": null,
            "id": 251259,
            "userId": 7215,
            "roleId": 55,
            "postId": 137047,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 55,
                "name": "Content Strategist",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T22:28:51.000Z",
        "updatedAt": null,
        "id": 137049,
        "url": "https://www.instagram.com/p/B7ucDHdBtKH",
        "account": "b.scar",
        "network": 2,
        "currentViews": 1676,
        "currentShares": null,
        "currentLikes": 360,
        "currentComments": 6,
        "currentDislikes": null,
        "postedAt": "2020-01-25T02:19:09.000Z",
        "caption": "And we’re back... Hi Quality Content took the red carpet at the Houston Sports Awards. Go peep that full video — LINK IN BIO #BScarTV",
        "thumbnailUrl": "thumbnails/45ed103434.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T22:29:13.000Z",
            "updatedAt": null,
            "id": 251261,
            "userId": 7215,
            "roleId": 55,
            "postId": 137049,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 55,
                "name": "Content Strategist",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T22:29:13.000Z",
            "updatedAt": null,
            "id": 251262,
            "userId": 7215,
            "roleId": 56,
            "postId": 137049,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 56,
                "name": "Content Producer",
                "weighting": 0,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T22:29:13.000Z",
            "updatedAt": null,
            "id": 251263,
            "userId": 7215,
            "roleId": 111,
            "postId": 137049,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }, {
        "createdAt": "2022-04-03T20:49:10.000Z",
        "updatedAt": null,
        "id": 137004,
        "url": "https://www.youtube.com/watch?v=nr-hpWNlSXc",
        "account": "Samsung US",
        "network": 4,
        "currentViews": 13488,
        "currentShares": null,
        "currentLikes": 332,
        "currentComments": 25,
        "currentDislikes": null,
        "postedAt": "2020-12-22T03:19:26.000Z",
        "caption": "See the #Samsung holiday gift guide for the holiday homebody: http://smsng.us/YaraGift\n\nWith everything going on in the world, the holidays are sure to look a bit different this year—but Yara Shahidi and her family know how to make the most of their time at home. Today’s mission? Yara’s brother Ehsan sets out to create the Shahidi Holiday Homebody Video with a little help from the #GalaxyS20Ultra and #Samsung.",
        "thumbnailUrl": "thumbnails/e1621f7f1a.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T20:49:23.000Z",
            "updatedAt": null,
            "id": 251160,
            "userId": 5371,
            "roleId": 71,
            "postId": 137004,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 5371,
                "name": "Samsung Electronics",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                "userTypeId": 1,
                "username": "Samsung",
                "termsAcknowledged": false,
                "userPermissions": [],
                "defaultRoleId": null,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 71,
                "name": "Talent Agency",
                "weighting": 400,
                "phasedOut": false
            }
        }, {
            "createdAt": "2022-04-03T20:49:23.000Z",
            "updatedAt": null,
            "id": 251161,
            "userId": 7215,
            "roleId": 111,
            "postId": 137004,
            "parentCreditId": 251160,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": {
                "createdAt": "2022-04-03T20:49:23.000Z",
                "updatedAt": null,
                "postId": 137004,
                "parentCreditId": null,
                "isPrivate": false,
                "isHidden": false,
                "user": {
                    "id": 5371,
                    "name": "Samsung Electronics",
                    "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
                    "userTypeId": 1,
                    "username": "Samsung",
                    "termsAcknowledged": false,
                    "userPermissions": [],
                    "defaultRoleId": null,
                    "isPro": false,
                    "isOG": false,
                    "isAdmin": false,
                    "isBeta": false,
                    "isFreePro": false
                },
                "role": {
                    "id": 71,
                    "name": "Talent Agency",
                    "weighting": 400,
                    "phasedOut": false
                }
            },
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 111,
                "name": "Talent Manager",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": "UCnEdfCdbxJJ9ouWKLSRCRRw",
        "isLive": true
    }, {
        "createdAt": "2022-04-03T22:28:08.000Z",
        "updatedAt": null,
        "id": 137048,
        "url": "https://www.instagram.com/p/CC2ND_7hp2y",
        "account": "b.scar",
        "network": 2,
        "currentViews": 2322,
        "currentShares": null,
        "currentLikes": 284,
        "currentComments": 14,
        "currentDislikes": null,
        "postedAt": "2020-07-20T02:23:20.000Z",
        "caption": "S1E2 w @dj_sneakerhead talking sneakers, profitable hobbies, & more.",
        "thumbnailUrl": "thumbnails/0aacf2995e.jpg",
        "type": 1,
        "credits": [{
            "createdAt": "2022-04-03T22:28:19.000Z",
            "updatedAt": null,
            "id": 251260,
            "userId": 7215,
            "roleId": 55,
            "postId": 137048,
            "parentCreditId": null,
            "isPrivate": false,
            "isHidden": false,
            "parentCredit": null,
            "user": {
                "id": 7215,
                "name": "Kelsy L Alston",
                "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/8e7812005b.jpg",
                "userTypeId": 2,
                "username": "Kelsylockett",
                "termsAcknowledged": true,
                "userPermissions": [{
                    "createdAt": "2022-04-03T20:27:44.000Z",
                    "updatedAt": null,
                    "id": 7674,
                    "userId": 7215,
                    "permission": 0
                }],
                "defaultRoleId": 111,
                "isPro": false,
                "isOG": false,
                "isAdmin": false,
                "isBeta": false,
                "isFreePro": false
            },
            "role": {
                "id": 55,
                "name": "Content Strategist",
                "weighting": 0,
                "phasedOut": false
            }
        }],
        "channelId": null,
        "isLive": true
    }],
    "meta": {
        "paging": {
            "page": 1,
            "size": 25,
            "lastPage": 2,
            "nextPage": 2,
            "prevPage": 0,
            "count": 32
        },
        "stats": {
            "totalLikes": 583310,
            "totalShares": 740,
            "totalComments": 3632,
            "totalViews": 26539836,
            "totalPosts": 32
        }
    }
}]

export const collaborators = {
    "success": 1,
    "error": 0,
    "data": [{
        "id": 5371,
        "name": "Samsung Electronics",
        "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/e17a04f1ab.jpg",
        "userTypeId": 1,
        "username": "Samsung",
        "termsAcknowledged": false,
        "defaultRoleId": null,
        "count": 25,
        "isPro": false
    }, {
        "id": 7218,
        "name": "Weber Shandwick",
        "avatarUrl": "https://freshtapemedia.nyc3.digitaloceanspaces.com/avatars/0f80cda62e.jpg",
        "userTypeId": 1,
        "username": "WeberShandwick",
        "termsAcknowledged": false,
        "defaultRoleId": null,
        "count": 10,
        "isPro": false
    }]
}


export const roles = [{
    "createdAt": "2021-10-12T16:47:51.000Z",
    "updatedAt": null,
    "id": 83,
    "name": "Account Manager",
    "weighting": 0,
    "phasedOut": false
}, {
    "createdAt": "2020-09-01T21:05:59.000Z",
    "updatedAt": "2020-09-01T21:05:59.000Z",
    "id": 32,
    "name": "Actor",
    "weighting": 0,
    "phasedOut": false
}, {
    "createdAt": "2020-09-01T21:05:59.000Z",
    "updatedAt": "2020-09-01T21:05:59.000Z",
    "id": 33,
    "name": "Actress",
    "weighting": 0,
    "phasedOut": false
}, {
    "createdAt": "2021-10-19T16:52:24.000Z",
    "updatedAt": null,
    "id": 134,
    "name": "Advertising Agency",
    "weighting": 0,
    "phasedOut": false
}]

export const tags = [
    {
    "id": 2969,
    "value": "ad"
}, {
    "id": 36647,
    "value": "ancestrydna"
}, {
    "id": 36644,
    "value": "ancestrypartner"
}, {
    "id": 822,
    "value": "art"
}, {
    "id": 4316,
    "value": "bscartv"
}, {
    "id": 3712,
    "value": "dadlife"
}, {
    "id": 36643,
    "value": "disclosure"
}, {
    "id": 823,
    "value": "drawing"
}, {
    "id": 4741,
    "value": "family"
}, {
    "id": 5645,
    "value": "familytime"
}, {
    "id": 1756,
    "value": "fyp"
}, {
    "id": 36736,
    "value": "galaxybudspro"
}, {
    "id": 36631,
    "value": "galaxys20ultra"
}, {
    "id": 36635,
    "value": "galaxytabs7+"
}, {
    "id": 36634,
    "value": "galaxywatch3."
}, {
    "id": 36737,
    "value": "galaxyzflip"
}, {
    "id": 36739,
    "value": "galaxyzfold2"
}, {
    "id": 36640,
    "value": "getthatcheddarentry"
}, {
    "id": 36633,
    "value": "giftguide"
}, {
    "id": 6168,
    "value": "mothersday"
}, {
    "id": 36645,
    "value": "myancestrystory"
}, {
    "id": 36646,
    "value": "myancestrystory."
}, {
    "id": 36637,
    "value": "qled4k"
}, {
    "id": 36641,
    "value": "realistic"
}, {
    "id": 36642,
    "value": "realorfake"
}, {
    "id": 31355,
    "value": "samsung"
}, {
    "id": 36632,
    "value": "samsung."
}, {
    "id": 36468,
    "value": "samsungpartner"
}, {
    "id": 36639,
    "value": "samsungpartner,"
}, {
    "id": 36628,
    "value": "samsungpartner#chocolatemommyluv"
}, {
    "id": 36626,
    "value": "samsungthombrowne"
}, {
    "id": 36638,
    "value": "smarttv."
}, {
    "id": 10749,
    "value": "stitch"
}, {
    "id": 3719,
    "value": "tbt"
}, {
    "id": 36627,
    "value": "teamgalaxy"
}, {
    "id": 36470,
    "value": "teamgalaxy."
}, {
    "id": 27086,
    "value": "withgalaxy"
}]